// Consumir el API para obtener los productos
fetch('http://localhost:5000/api/products') // URL del endpoint del backend
    .then(response => response.json())
    .then(products => {
        const productList = document.getElementById('product-list'); // Lista de productos en el HTML
        productList.innerHTML = ''; // Asegurarse de limpiar cualquier contenido previo

        // Recorrer los productos y mostrarlos en la lista
        products.forEach(product => {
            const li = document.createElement('li');
            li.innerHTML = `
                <strong>${product.name}</strong> - $${product.price.toFixed(2)}<br>
                ${product.description} <br>
                <small>Disponibles: ${product.quantity}</small>
            `;
            productList.appendChild(li);
        });
    })
    .catch(error => console.error('Error al obtener los productos:', error));
