document.getElementById('register-form').addEventListener('submit', async (event) => {
    event.preventDefault(); // Evitar recargar la página

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const role = document.getElementById('role').value;

    try {
        const response = await fetch('http://localhost:5000/api/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password, role })
        });

        const data = await response.json();

        if (response.ok) {
            document.getElementById('response-message').innerText = `¡Registro exitoso! Bienvenido, ${data.user.username}.`;
            document.getElementById('register-form').reset();
        } else {
            document.getElementById('response-message').innerText = `Error: ${data.message}`;
        }
    } catch (error) {
        document.getElementById('response-message').innerText = `Error: No se pudo conectar con el servidor.`;
    }
});
