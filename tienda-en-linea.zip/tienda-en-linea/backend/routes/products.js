const express = require('express');
const router = express.Router();

// Productos ficticios
const products = require('../data/products.json');

// Obtener productos
router.get('/', (req, res) => {
    res.json(products);
});

module.exports = router;
