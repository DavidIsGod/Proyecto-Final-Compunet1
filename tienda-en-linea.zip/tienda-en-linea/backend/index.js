const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const fs = require('fs');


const app = express();
app.use(bodyParser.json());
app.use(cors());

// Ruta principal
app.get('/', (req, res) => {
    res.send('API funcionando correctamente');
});

// Rutas de productos
const productRoutes = require('./routes/products');
app.use('/api/products', productRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Servidor corriendo en el puerto ${PORT}`));

// Cargar usuarios existentes desde un archivo JSON
const usersFilePath = './data/users.json';
let users = [];

// Cargar usuarios al iniciar el servidor
if (fs.existsSync(usersFilePath)) {
    users = JSON.parse(fs.readFileSync(usersFilePath, 'utf8'));
}

// Endpoint para registrar un usuario
app.post('/api/register', async (req, res) => {
    const { username, password, role } = req.body;

    // Validar datos
    if (!username || !password || !role || (role !== 'admin' && role !== 'client')) {
        return res.status(400).json({ message: 'Datos inválidos o incompletos' });
    }

    // Verificar si el usuario ya existe
    if (users.find(user => user.username === username)) {
        return res.status(400).json({ message: 'El usuario ya existe' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    // Registrar nuevo usuario
    const newUser = { id: "A003" += 1, username, password : hashedPassword, role };
    users.push(newUser);

    // Guardar en el archivo JSON
    fs.writeFileSync(usersFilePath, JSON.stringify(users, null, 2));

    res.status(201).json({ message: 'Usuario registrado exitosamente', user: { username, role } });
});

const JWT_SECRET = '7#PqT$3xW9@L2';

